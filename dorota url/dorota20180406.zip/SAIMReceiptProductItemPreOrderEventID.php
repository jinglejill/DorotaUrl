<?php
    include_once('dbConnect.php');
    setConnectionValue($_POST['dbName']);
    writeToLog("file: " . basename(__FILE__));
    
    
    if (isset ($_POST["countProduct"]))
    {
        $countProduct = $_POST["countProduct"];
        for($i=0; $i<$countProduct; $i++)
        {
            $productMainID[$i] = $_POST["productMainID".sprintf("%02d", $i)];
            $status[$i] = $_POST["status".sprintf("%02d", $i)];
        }
    }
    if (isset ($_POST["countReceiptProductItem"]))
    {
        $countReceiptProductItem = $_POST["countReceiptProductItem"];
        for($i=0; $i<$countReceiptProductItem; $i++)
        {
            $receiptProductItemID[$i] = $_POST["receiptProductItemID".sprintf("%02d", $i)];
            $preOrderEventID[$i] = $_POST["preOrderEventID".sprintf("%02d", $i)];
            $productID[$i] = $_POST["productID".sprintf("%02d", $i)];
        }
    }
    if (isset($_POST["countPreOrderEventIDHistory"]))
    {
        $countPreOrderEventIDHistory = $_POST["countPreOrderEventIDHistory"];
        for($i=0; $i<$countPreOrderEventIDHistory; $i++)
        {
            $preOrderEventIDHistoryID[$i] = $_POST["preOrderEventIDHistoryID".sprintf("%02d", $i)];
            $receiptProductItemIDPreHis[$i] = $_POST["receiptProductItemIDPreHis".sprintf("%02d", $i)];
            $preOrderEventIDPreHis[$i] = $_POST["preOrderEventIDPreHis".sprintf("%02d", $i)];
        }
    }
    

    
    // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    
    // Set autocommit to off
    mysqli_autocommit($con,FALSE);
    writeToLog("set auto commit to off");
    
    
    //product
    for($i=0; $i<$countProduct; $i++)
    {
        //query statement
        $sql = "update Product set status = '$status[$i]' where ProductID = '$productMainID[$i]'";
        $ret = doQueryTask2($con,$sql,$_POST["modifiedUser"]);
        if($ret != "")
        {
            mysqli_rollback($con);
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
        
    }
    
    
    //select row ที่แก้ไข ขึ้นมาเก็บไว้
    $sql = "select * from Product where `ProductID` in ('$productMainID[0]'";
    for($i=1; $i<$countProduct; $i++)
    {
        $sql .= ",'$productMainID[$i]'";
    }
    $sql .= ")";
    $selectedRow = getSelectedRow($sql);
    
    
    //broadcast ไป device token อื่น
    $type = 'tProduct';
    $action = 'u';
    $ret = doPushNotificationTask($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
    if($ret != "")
    {
        putAlertToDevice($_POST["modifiedUser"]);
        echo json_encode($ret);
        exit();
    }
    
    
    
    
    
    //PreOrderEventIDHistory
    for($i=0; $i<$countReceiptProductItem; $i++)
    {
        $sql = "insert into PreOrderEventIDHistory (ReceiptProductItemID, PreOrderEventID) values($receiptProductItemID[$i],$preOrderEventID[$i])";
        $ret = doQueryTask2($con,$sql,$_POST["modifiedUser"]);
        $preOrderEventIDHistoryID = mysqli_insert_id($con);
        if($ret != "")
        {
            mysqli_rollback($con);
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
        
        
        //select row ที่แก้ไข ขึ้นมาเก็บไว้
        $sql = "select * from PreOrderEventIDHistory where `PreOrderEventIDHistoryID` = $preOrderEventIDHistoryID";
        $selectedRow = getSelectedRow($sql);
        
        
        //broadcast ไป device token อื่น
        $type = 'tPreOrderEventIDHistory';
        $action = 'i';
        $ret = doPushNotificationTask($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
        if($ret != "")
        {
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
    }
    
    
    
    //receiptproductitem
    for($i=0; $i<$countReceiptProductItem; $i++)
    {
        //query statement
        $sql = "update ReceiptProductItem set PreOrderEventID = $preOrderEventID[$i], ProductID='$productID[$i]' where ReceiptProductItemID = $receiptProductItemID[$i]";
        $ret = doQueryTask2($con,$sql,$_POST["modifiedUser"]);
        if($ret != "")
        {
            mysqli_rollback($con);
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
        
    }
    
    
    //select row ที่แก้ไข ขึ้นมาเก็บไว้
    $sql = "select * from ReceiptProductItem where `ReceiptProductItemID` in ('$receiptProductItemID[0]'";
    for($i=1; $i<$countReceiptProductItem; $i++)
    {
        $sql .= ",'$receiptProductItemID[$i]'";
    }
    $sql .= ")";
    $selectedRow = getSelectedRow($sql);
    
    
    //broadcast ไป device token อื่น
    $type = 'tReceiptProductItem';
    $action = 'u';
    $ret = doPushNotificationTask($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
    if($ret != "")
    {
        putAlertToDevice($_POST["modifiedUser"]);
        echo json_encode($ret);
        exit();
    }
    
    
    
    
    //PreOrderEventIDHistory
    if($countPreOrderEventIDHistory > 0)
    {
        for($i=0; $i<$countPreOrderEventIDHistory; $i++)
        {
            $j=0;
            for(;$j<30;)
            {
                //insert  โดยเปลี่ยน id ขึ้นทีละ 1
                //query statement
                $sql = "insert into PreOrderEventIDHistory (PreOrderEventIDHistoryID, ReceiptProductItemID, PreOrderEventID) values (" . ($preOrderEventIDHistoryID[$i]+$j). ",$receiptProductItemIDPreHis[$i],$preOrderEventIDPreHis[$i])";
                $ret = doQueryTask2($con,$sql,$_POST["modifiedUser"]);
                if($ret == "")
                {
                    break;
                }
                else
                {
                    //insert ไม่ผ่าน อาจจะเพราะ id duplicate
                    $j++;
                }
            }
            
            if($j==30)
            {
                mysqli_rollback($con);
                putAlertToDevice($_POST["modifiedUser"]);
                echo json_encode($ret);
                exit();
            }
            else if($j != 0)
            {
                //มีการเปลีี่ยน id
                //select row ที่แก้ไข ขึ้นมาเก็บไว้
                $sql = "select $preOrderEventIDHistoryID[$i] as PreOrderEventIDHistoryID, 1 as ReplaceSelf, '$modifiedUser' as ModifiedUser";
                $selectedRow = getSelectedRow($sql);
                
                
                
                //broadcast ไป device token ตัวเอง
                $type = 'tPreOrderEventIDHistory';
                $action = 'd';
                $ret = doPushNotificationTaskToDevice($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
                if($ret != "")
                {
                    putAlertToDevice($_POST["modifiedUser"]);
                    echo json_encode($ret);
                    exit();
                }
                
                
                
                //select row ที่แก้ไข ขึ้นมาเก็บไว้
                $preOrderEventIDHistoryID[$i] = $preOrderEventIDHistoryID[$i]+$j;
                $sql = "select *, 1 IDInserted from PreOrderEventIDHistory where `PreOrderEventIDHistoryID` = $preOrderEventIDHistoryID[$i]";
                $selectedRow = getSelectedRow($sql);
                
                
                
                //broadcast ไป device token ตัวเอง
                $type = 'tPreOrderEventIDHistory';
                $action = 'i';
                $ret = doPushNotificationTaskToDevice($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
                if($ret != "")
                {
                    putAlertToDevice($_POST["modifiedUser"]);
                    echo json_encode($ret);
                    exit();
                }
            }
            else if($j == 0)
            {
                //update IDInserted
                //select row ที่แก้ไข ขึ้นมาเก็บไว้
                $sql = "select *, 1 IDInserted from PreOrderEventIDHistory where `PreOrderEventIDHistoryID` = $preOrderEventIDHistoryID[$i]";
                $selectedRow = getSelectedRow($sql);
                
                
                
                //broadcast ไป device token ตัวเอง
                $type = 'tPreOrderEventIDHistory';
                $action = 'u';
                $ret = doPushNotificationTaskToDevice($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
                if($ret != "")
                {
                    putAlertToDevice($_POST["modifiedUser"]);
                    echo json_encode($ret);
                    exit();
                }
            }
            
            
            
            
            //select row ที่แก้ไข ขึ้นมาเก็บไว้
            $sql = "select *, 1 IDInserted from PreOrderEventIDHistory where `PreOrderEventIDHistoryID` = $preOrderEventIDHistoryID[$i]";
            $selectedRow = getSelectedRow($sql);
            
            
            //broadcast ไป device token อื่น
            $type = 'tPreOrderEventIDHistory';
            $action = 'i';
            $ret = doPushNotificationTask($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
            if($ret != "")
            {
                putAlertToDevice($_POST["modifiedUser"]);
                echo json_encode($ret);
                exit();
            }
            
        }
    }
    
    
    //do script successful
    sendPushNotificationToOtherDevices($_POST["modifiedDeviceToken"]);
    writeToLog("query commit, file: " . basename(__FILE__));
    mysqli_commit($con);
    mysqli_close($con);
    $response = array('status' => '1', 'sql' => $sql);    
    
    
    echo json_encode($response);
    exit();
?>
