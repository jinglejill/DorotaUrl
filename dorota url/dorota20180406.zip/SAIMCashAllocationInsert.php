<?php
    include_once('dbConnect.php');
    setConnectionValue($_POST['dbName']);
    writeToLog("file: " . basename(__FILE__));
    
    
    if (isset ($_POST["cashAllocationID"]) &&
        isset ($_POST["eventID"]) &&
        isset ($_POST["cashChanges"]) &&
        isset ($_POST["cashTransfer"]) &&
        isset ($_POST["inputDate"])
        )
    {
        $cashAllocationID = $_POST["cashAllocationID"];
        $eventID = $_POST["eventID"];
        $cashChanges = $_POST["cashChanges"];
        $cashTransfer = $_POST["cashTransfer"];
        $inputDate = $_POST["inputDate"];
        
    } else {
        $cashAllocationID = 0;
        $eventID = 0;
        $cashChanges = 0;
        $cashTransfer = 0;
        $inputDate = '';
    }
    
    
    
    // Check connection
    if (mysqli_connect_errno())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    
    
    // Set autocommit to off
    mysqli_autocommit($con,FALSE);
    writeToLog("set auto commit to off");
    
    
    //query statement
    $j=0;
    for(;$j<30;)
    {
        //insert  โดยเปลี่ยน id ขึ้นทีละ 1
        //query statement
        $sql = "INSERT INTO `cashallocation`(`CashAllocationID`, `EventID`, `CashChanges`, `CashTransfer`, `InputDate`) VALUES (" . ($cashAllocationID+$j) . ",'$eventID','$cashChanges','$cashTransfer','$inputDate')";
        $ret = doQueryTask2($con,$sql,$_POST["modifiedUser"]);
        if($ret == "")
        {
            break;
        }
        else
        {
            //insert ไม่ผ่าน อาจจะเพราะ id duplicate
            $j++;
        }
    }
    
    if($j==30)
    {
        mysqli_rollback($con);
        putAlertToDevice($_POST["modifiedUser"]);
        echo json_encode($ret);
        exit();
    }
    else if($j != 0)
    {
        //มีการเปลีี่ยน id
        //select row ที่แก้ไข ขึ้นมาเก็บไว้
        $sql = "select *, 1 as ReplaceSelf from cashallocation where `CashAllocationID` = $cashAllocationID";
        $selectedRow = getSelectedRow($sql);
        
        
        
        //broadcast ไป device token ตัวเอง
        $type = 'tCashAllocation';
        $action = 'd';
        $ret = doPushNotificationTaskToDevice($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
        if($ret != "")
        {
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
        
        
        
        //select row ที่แก้ไข ขึ้นมาเก็บไว้
        $cashAllocationID = $cashAllocationID+$j;
        $sql = "select *, 1 IDInserted from cashallocation where `CashAllocationID` = $cashAllocationID";
        $selectedRow = getSelectedRow($sql);
        
        
        
        //broadcast ไป device token ตัวเอง
        $type = 'tCashAllocation';
        $action = 'i';
        $ret = doPushNotificationTaskToDevice($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
        if($ret != "")
        {
            putAlertToDevice($_POST["modifiedUser"]);
            echo json_encode($ret);
            exit();
        }
    }
    
    
    //select row ที่แก้ไข ขึ้นมาเก็บไว้
    $sql = "select * from cashallocation where `CashAllocationID` = $cashAllocationID";
    $selectedRow = getSelectedRow($sql);
    
    
    //broadcast ไป device token อื่น
    $type = 'tCashAllocation';
    $action = 'i';
    $ret = doPushNotificationTask($con,$_POST["modifiedUser"],$_POST["modifiedDeviceToken"],$selectedRow,$type,$action);
    if($ret != "")
    {
        putAlertToDevice($_POST["modifiedUser"]);
        echo json_encode($ret);
        exit();
    }
    
    
    
    //do script successful
    mysqli_commit($con);
    mysqli_close($con);
    sendPushNotificationToOtherDevices($_POST["modifiedDeviceToken"]);
    writeToLog("query commit, file: " . basename(__FILE__));
    $response = array('status' => '1', 'sql' => $sql);
    
    
    echo json_encode($response);
    exit();
?>
